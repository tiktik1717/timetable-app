import { useEffect, useState } from "react";

export default function TeacherView({
    teachers,
    classes,
    days,
    selectedTeacherForView,
    setSelectedTeacherForView,
    getCellUnitIds,
    getUnitById,
    getClassHoursForDay,
    checkpoints,
    comparisonCheckpointId,
    setComparisonCheckpointId,
    isTeacherCellChanged,
    setSchoolData,
    isTeacherFreeDay,
    isTeacherBlockedHour,
    removeTeacherFromSpecificTime,
    requestPurpleHoleCheck,
    teacherHasViewChanges,
    teachingUnits,
    countScheduledUnitHours,
}) {
    const selectedTeacher = teachers.find(
        (teacher) => teacher.id === selectedTeacherForView
    );

    function getTeacherLessons(day, hour) {
        const lessons = [];

        for (const className of classes) {
            if (hour > getClassHoursForDay(className, day)) continue;

            const unitIds = getCellUnitIds(day, className, hour);

            for (const unitId of unitIds) {
                const unit = getUnitById(unitId);

                if (unit?.teacherId === selectedTeacherForView) {
                    lessons.push(
                        unit.subject && unit.subject !== "רגיל"
                            ? `${className} / ${unit.subject}`
                            : className
                    );
                }
            }
        }

        return lessons;
    }

    function toggleBlockedHour(day, hour) {
        if (!selectedTeacherForView) return;

        if (isTeacherFreeDay(selectedTeacherForView, day)) {
            return;
        }
        const wasBlocked = isTeacherBlockedHour(selectedTeacherForView, day, hour);
        setSchoolData((prev) => ({
            ...prev,
            teachers: prev.teachers.map((teacher) => {
                if (teacher.id !== selectedTeacherForView) return teacher;

                const blockedHours = { ...(teacher.blockedHours || {}) };
                const dayHours = blockedHours[day] || [];

                const hourNumber = Number(hour);

                blockedHours[day] = dayHours.includes(hourNumber)
                    ? dayHours.filter((h) => h !== hourNumber)
                    : [...dayHours, hourNumber].sort((a, b) => a - b);

                return {
                    ...teacher,
                    blockedHours,
                };
            }),
        }));
        if (!wasBlocked) {
            requestPurpleHoleCheck();
            const result = removeTeacherFromSpecificTime(
                selectedTeacherForView,
                day,
                hour
            );

            if (result.removedCount > 0) {
                const groupsText =
                    result.removedGroups.length > 0
                        ? `\nהוסרו גם קבוצות: ${result.removedGroups.join(", ")}`
                        : "";

                alert(
                    `בעקבות חסימת השעה הוסרו ${result.removedCount} שיבוץ/ים.${groupsText}`
                );
            }
        }
    }

    const maxHoursForAllClasses = Math.max(
        0,
        ...days.map((day) =>
            Math.max(
                0,
                ...classes.map((className) => getClassHoursForDay(className, day))
            )
        )
    );

    const visibleHours = Array.from(
        { length: maxHoursForAllClasses },
        (_, index) => index + 1
    );

    const [showChangedTeachersOnly, setShowChangedTeachersOnly] = useState(false);

    const baseVisibleTeachers =
        showChangedTeachersOnly && comparisonCheckpointId
            ? teachers.filter((teacher) => teacherHasViewChanges(teacher.id))
            : teachers;

    const visibleTeachersForView = [...baseVisibleTeachers].sort((a, b) =>
        (a.name || "").localeCompare(b.name || "", "he")
    );

    const visibleTeachersByCode = [...baseVisibleTeachers].sort((a, b) =>
        String(a.id).localeCompare(String(b.id), "he", {
            numeric: true,
            sensitivity: "base",
        })
    );

    const currentTeacherIndex = visibleTeachersForView.findIndex(
        (teacher) => teacher.id === selectedTeacherForView
    );

    useEffect(() => {
        if (
            visibleTeachersForView.length > 0 &&
            !visibleTeachersForView.some(
                (teacher) => teacher.id === selectedTeacherForView
            )
        ) {
            setSelectedTeacherForView(visibleTeachersForView[0].id);
        }
    }, [showChangedTeachersOnly, comparisonCheckpointId, teachers]);

    function goToPreviousTeacher() {
        if (visibleTeachersForView.length === 0) return;

        const index = visibleTeachersForView.findIndex(
            (teacher) => teacher.id === selectedTeacherForView
        );

        const nextIndex =
            index <= 0 ? visibleTeachersForView.length - 1 : index - 1;

        setSelectedTeacherForView(visibleTeachersForView[nextIndex].id);
    }

    function goToNextTeacher() {
        if (visibleTeachersForView.length === 0) return;

        const index = visibleTeachersForView.findIndex(
            (teacher) => teacher.id === selectedTeacherForView
        );

        const nextIndex =
            index === -1 || index >= visibleTeachersForView.length - 1
                ? 0
                : index + 1;

        setSelectedTeacherForView(visibleTeachersForView[nextIndex].id);
    }

    const teacherProgress = (() => {
        const teacherUnits = (teachingUnits || []).filter(
            (unit) => unit.teacherId === selectedTeacherForView
        );

        function calculateForUnits(units) {
            const totalHours = units.reduce(
                (sum, unit) => sum + Math.max(0, Number(unit.hours) || 0),
                0
            );

            const placedHours = units.reduce((sum, unit) => {
                const requiredHours = Math.max(0, Number(unit.hours) || 0);
                const scheduledHours = countScheduledUnitHours
                    ? countScheduledUnitHours(unit.id)
                    : 0;

                return sum + Math.min(requiredHours, scheduledHours);
            }, 0);

            const percentage =
                totalHours === 0
                    ? 0
                    : Math.min(100, Math.round((placedHours / totalHours) * 100));

            return { totalHours, placedHours, percentage };
        }

        return {
            classes: calculateForUnits(
                teacherUnits.filter((unit) => unit.type !== "teamMeeting")
            ),
            meetings: calculateForUnits(
                teacherUnits.filter((unit) => unit.type === "teamMeeting")
            ),
        };
    })();

    return (
        <div className="teacher-view">
            <div className="teacher-view-header">
                <h3>תצוגת מורה</h3>

                <label>
                    מורה:
                    <select
                        value={selectedTeacherForView}
                        onChange={(e) => setSelectedTeacherForView(e.target.value)}
                    >
                        {visibleTeachersForView.map((teacher) => (
                            <option key={teacher.id} value={teacher.id}>
                                {teacher.name}
                            </option>
                        ))}
                    </select>
                </label>

                <label>
                    קוד מורה:
                    <select
                        value={selectedTeacherForView}
                        onChange={(e) => setSelectedTeacherForView(e.target.value)}
                    >
                        {visibleTeachersByCode.map((teacher) => (
                            <option key={teacher.id} value={teacher.id}>
                                {teacher.id}
                            </option>
                        ))}
                    </select>
                </label>

                <label>
                    השווה מול:
                    <select
                        value={comparisonCheckpointId}
                        onChange={(e) => setComparisonCheckpointId(e.target.value)}
                    >
                        <option value="">ללא השוואה</option>

                        {checkpoints.map((checkpoint) => (
                            <option key={checkpoint.id} value={checkpoint.id}>
                                {checkpoint.name}
                            </option>
                        ))}
                    </select>
                </label>
                <button type="button" className="mini-button" onClick={goToPreviousTeacher}>
                    הקודם
                </button>

                <button type="button" className="mini-button" onClick={goToNextTeacher}>
                    הבא
                </button>

                <label className="inline-checkbox">
                    <input
                        type="checkbox"
                        checked={showChangedTeachersOnly}
                        disabled={!comparisonCheckpointId}
                        onChange={(e) => setShowChangedTeachersOnly(e.target.checked)}
                    />
                    הצג מורים ששונו בלבד
                </label>
            </div>

            <div className="teacher-view-note">
                לחיצה על תא פנוי מסמנת/מבטלת שעה חסומה למורה. ימים חופשיים מנוהלים במסך ניהול מורים בלבד.
            </div>

            <div className="teacher-scheduling-progress" aria-live="polite">
                <strong>{selectedTeacher?.name || ""}</strong>

                <div className="teacher-progress-row">
                    <span>שעות בכיתות</span>
                    <span>
                        {teacherProgress.classes.placedHours}/{teacherProgress.classes.totalHours}
                    </span>
                    <div
                        className="view-scheduling-progress-track"
                        role="progressbar"
                        aria-label="התקדמות שיבוץ שעות בכיתות"
                        aria-valuemin="0"
                        aria-valuemax="100"
                        aria-valuenow={teacherProgress.classes.percentage}
                        title={`${teacherProgress.classes.placedHours} מתוך ${teacherProgress.classes.totalHours} שעות בכיתות שובצו`}
                    >
                        <div
                            className="view-scheduling-progress-fill"
                            style={{ width: `${teacherProgress.classes.percentage}%` }}
                        />
                    </div>
                </div>

                <div className="teacher-progress-row">
                    <span>ישיבות צוות</span>
                    <span>
                        {teacherProgress.meetings.placedHours}/{teacherProgress.meetings.totalHours}
                    </span>
                    <div
                        className="view-scheduling-progress-track"
                        role="progressbar"
                        aria-label="התקדמות שיבוץ ישיבות צוות"
                        aria-valuemin="0"
                        aria-valuemax="100"
                        aria-valuenow={teacherProgress.meetings.percentage}
                        title={`${teacherProgress.meetings.placedHours} מתוך ${teacherProgress.meetings.totalHours} שעות ישיבות צוות שובצו`}
                    >
                        <div
                            className="view-scheduling-progress-fill"
                            style={{ width: `${teacherProgress.meetings.percentage}%` }}
                        />
                    </div>
                </div>
            </div>

            <table className="teacher-view-table">
                <thead>
                    <tr>
                        <th>שעה</th>
                        {days.map((day) => (
                            <th
                                key={day}
                                className={
                                    isTeacherFreeDay(selectedTeacherForView, day)
                                        ? "teacher-free-day-header"
                                        : ""
                                }
                            >
                                יום {day}
                            </th>
                        ))}
                    </tr>
                </thead>

                <tbody>
                    {visibleHours.map((hour) => (
                        <tr key={hour}>
                            <td className="teacher-view-hour">שעה {hour}</td>

                            {days.map((day) => {
                                const lessons = getTeacherLessons(day, hour);
                                const isFreeDay = isTeacherFreeDay(selectedTeacherForView, day);
                                const isBlocked = isTeacherBlockedHour(
                                    selectedTeacherForView,
                                    day,
                                    hour
                                );

                                const changed = isTeacherCellChanged?.(
                                    selectedTeacherForView,
                                    day,
                                    hour
                                );

                                return (
                                    <td
                                        key={day}
                                        className={[
                                            "teacher-view-cell",
                                            changed ? "changed-cell" : "",
                                            isFreeDay ? "teacher-free-day-cell" : "",
                                            isBlocked ? "teacher-blocked-hour-cell" : "",
                                        ].join(" ")}
                                        onClick={() => toggleBlockedHour(day, hour)}
                                        title={
                                            isFreeDay
                                                ? "יום חופשי — ניתן לשינוי במסך ניהול מורים"
                                                : isBlocked
                                                    ? "שעה חסומה — לחץ לביטול"
                                                    : "לחץ כדי לחסום שעה זו"
                                        }
                                    >
                                        {lessons.map((lesson, index) => (
                                            <div key={index}>{lesson}</div>
                                        ))}
                                    </td>
                                );
                            })}
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}