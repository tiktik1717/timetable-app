import { useState } from "react";
import {
  solveWithAgent,
} from "../scheduling/agentSolver";
import {
  evaluateFormalRules,
  formalRuleEvaluationsToRuleCheckResults,
} from "../scheduling/ruleEvaluator";

export default function SchedulingAgentView({
  agentContext,
  validationReport,
  rules,
  onRulesChange,
  approvedExceptions,
  onApprovedExceptionsChange,
  messages,
  onMessagesChange,
  onSimulateScheduleMove,

  workspace,
  onStartWorkspace,
  onClearWorkspace,

  onTryWorkspaceMove,
  onTryWorkspaceMovePure,
}) {
  const [input, setInput] = useState("");
  const [newRuleText, setNewRuleText] = useState("");
  const [isAgentThinking, setIsAgentThinking] = useState(false);
  const [isSandboxTesting, setIsSandboxTesting] = useState(false);
  const [sandboxTestResult, setSandboxTestResult] = useState(null);
  const [agentTelemetry, setAgentTelemetry] = useState({
    calls: 0,
    inputTokens: 0,
    outputTokens: 0,
    totalTokens: 0,
    totalDurationMs: 0,
    lastModel: null,
    lastContextChars: 0,
    lastContextProfile: null,
  });

  function recordTelemetry(telemetry) {
    if (!telemetry) return;

    setAgentTelemetry((prev) => ({
      calls: prev.calls + 1,
      inputTokens:
        prev.inputTokens +
        (Number(telemetry.inputTokens) || 0),
      outputTokens:
        prev.outputTokens +
        (Number(telemetry.outputTokens) || 0),
      totalTokens:
        prev.totalTokens +
        (Number(telemetry.totalTokens) || 0),
      totalDurationMs:
        prev.totalDurationMs +
        (Number(telemetry.durationMs) || 0),
      lastModel:
        telemetry.model || prev.lastModel,
      lastContextChars:
        Number(telemetry.contextChars) || 0,
      lastContextProfile:
        telemetry.contextProfile || null,
    }));
  }

  function buildDeterministicRuleCheckResults(scheduleOverride = null) {
    const scheduleToCheck =
      scheduleOverride ||
      workspace?.workingSchedule ||
      agentContext?.baseSchedule ||
      {};

    const evaluations = evaluateFormalRules({
      rules: rules || [],
      schedule: scheduleToCheck,
      schoolData: agentContext?.schoolData || {},
    });

    return {
      evaluations,
      ruleCheckResults:
        formalRuleEvaluationsToRuleCheckResults(
          evaluations,
        ),
    };
  }

  function mergeRuleCheckResults(
    agentResults = [],
    deterministicResults = [],
  ) {
    const merged = new Map();

    for (const result of agentResults || []) {
      if (result?.ruleId) {
        merged.set(result.ruleId, result);
      }
    }

    // Deterministic checks take precedence over an LLM judgment for the
    // same rule, because they were evaluated directly against the schedule.
    for (const result of deterministicResults || []) {
      if (result?.ruleId) {
        merged.set(result.ruleId, result);
      }
    }

    return [...merged.values()];
  }

  async function runPythonSandboxTest() {
    if (isSandboxTesting) return;

    const schoolData = agentContext?.schoolData;
    if (!schoolData) {
      setSandboxTestResult({
        success: false,
        error: "אין schoolData זמין לבדיקת ה-Sandbox.",
      });
      return;
    }

    setIsSandboxTesting(true);
    setSandboxTestResult(null);

    try {
      const response = await fetch(
        "/.netlify/functions/python-sandbox-test",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ schoolData }),
        },
      );

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data?.error || "בדיקת Python Sandbox נכשלה");
      }

      setSandboxTestResult(data);
      recordTelemetry(data.telemetry);
    } catch (error) {
      console.error("Python sandbox test failed:", error);
      setSandboxTestResult({
        success: false,
        error: error?.message || "שגיאה לא ידועה בבדיקת ה-Sandbox",
      });
    } finally {
      setIsSandboxTesting(false);
    }
  }

  function createAgentMessage(text, type = "message", actions = []) {
    return {
      id: `agent-${Date.now()}-${Math.random().toString(36).slice(2)}`,
      role: "agent",
      type,
      text,
      createdAt: new Date().toISOString(),
      actions,
    };
  }

  async function runAgentSolver(
    initialAction
  ) {
    const initialWorkspace =
      workspace ||
      onStartWorkspace?.();

    if (
      !initialWorkspace ||
      !onTryWorkspaceMovePure
    ) {
      return null;
    }

    const result =
      await solveWithAgent({
        initialAction,

        workspace:
          initialWorkspace,

        tryWorkspaceMove:
          onTryWorkspaceMovePure,

        evaluateAttempt:
          async ({
            attemptedAction,
            attemptResult,
          }) => {
            return await askAgentToEvaluateAttempt({
              attemptedAction,
              attemptResult,
            });
          },
      });

    console.log(
      "AGENT SOLVER RESULT:",
      result
    );

    return result;
  }

  function buildTeacherScheduleSummary(
    scheduleOverride = null
  ) {
    const schedule =
      scheduleOverride ||
      agentContext?.baseSchedule ||
      {};

    const units =
      agentContext?.schoolData?.teachingUnits || [];

    const byUnitId = new Map(
      units.map((unit) => [unit.id, unit])
    );

    // Compact wire format. Teacher names are already present in entitySummary,
    // so the schedule snapshot sends only placements. This removes thousands
    // of repeated JSON field names from every LLM call.
    // placement tuple = [day, hour, className, unitId]
    const byTeacher = {};

    for (const [day, daySchedule] of Object.entries(schedule)) {
      for (const [className, classSchedule] of Object.entries(daySchedule || {})) {
        for (const [hourKey, cellValue] of Object.entries(classSchedule || {})) {
          const hour = Number(hourKey);
          const unitIds = Array.isArray(cellValue)
            ? cellValue
            : cellValue
              ? [cellValue]
              : [];

          for (const unitId of unitIds) {
            const unit = byUnitId.get(unitId);
            if (!unit?.teacherId) continue;

            const teacherId = String(unit.teacherId);
            if (!byTeacher[teacherId]) {
              byTeacher[teacherId] = [];
            }

            byTeacher[teacherId].push([
              day,
              hour,
              className,
              unitId,
            ]);
          }
        }
      }
    }

    for (const placements of Object.values(byTeacher)) {
      placements.sort((a, b) => {
        const dayOrder =
          (agentContext?.schoolData?.days || []).indexOf(a[0]) -
          (agentContext?.schoolData?.days || []).indexOf(b[0]);
        return dayOrder || a[1] - b[1] || String(a[2]).localeCompare(String(b[2]));
      });
    }

    return {
      format: "teacher-placements-v2",
      fields: ["day", "hour", "className", "unitId"],
      byTeacher,
    };
  }

  async function askAgentToEvaluateAttempt({
    attemptedAction,
    attemptResult,
  }) {
    const workspaceSchedule =
      attemptResult?.workspace
        ?.workingSchedule;

    const workspaceTeacherSummary =
      buildTeacherScheduleSummary(
        workspaceSchedule
      );

    const deterministicRules =
      buildDeterministicRuleCheckResults(
        workspaceSchedule,
      );

    const response = await fetch(
      "/.netlify/functions/scheduling-agent",
      {
        method: "POST",

        headers: {
          "Content-Type":
            "application/json",
        },

        body: JSON.stringify({
          message: `
בוצע עכשיו ניסיון אוטומטי בתוך Agent Workspace.

הפעולה שנוסתה:
${JSON.stringify(
            attemptedAction,
            null,
            2
          )}

תוצאת הניסיון:
${JSON.stringify(
            {
              success:
                attemptResult.success,

              error:
                attemptResult.error,

              validationComparison:
                attemptResult
                  .validationComparison,
            },
            null,
            2
          )}

זו אינה המערכת האמיתית אלא working schedule זמני.

בדוק עכשיו האם הניסיון פתר את הבעיה שביקש המשתמש לפתור.

אם הניסיון נכשל או לא פתר את הבעיה,
מצא בעצמך ניסיון אחר.

אם הניסיון פתר את הבעיה ולא יצר בעיית Core חדשה,
דווח שהמועמד מתאים להמשך בדיקה.
        `,

          conversationHistory:
            messages || [],

          validationSummary:
            attemptResult
              ?.validationReport || {},

          entitySummary: {
            teachers:
              agentContext?.schoolData
                ?.teachers?.map(
                  (teacher) => ({
                    id: teacher.id,
                    name: teacher.name,
                  })
                ) || [],

            classes:
              agentContext?.schoolData
                ?.classes || [],

            meetings:
              agentContext?.schoolData
                ?.meetings?.map(
                  (meeting) => ({
                    id: meeting.id,
                    name: meeting.name,
                  })
                ) || [],
          },

          teacherScheduleSummary:
            workspaceTeacherSummary,

          rules: rules || [],

          approvedExceptions:
            approvedExceptions || [],

          formalRuleEvaluations:
            deterministicRules.evaluations,
        }),
      }
    );

    const data = await response.json();

    if (!response.ok) {
      throw new Error(
        data?.error ||
        "שגיאה בבדיקת ניסיון הסוכן"
      );
    }

    recordTelemetry(data.telemetry);

    return {
      ...data,
      ruleCheckResults: mergeRuleCheckResults(
        data.ruleCheckResults || [],
        deterministicRules.ruleCheckResults,
      ),
    };
  }

  async function handleSend() {
    const text = input.trim();

    if (!text || isAgentThinking) {
      return;
    }

    // בדיקה זמנית:
    // בניית תקציר מערכת השעות לפי מורים.
    // בשלב זה עדיין לא שולחים אותו לסוכן.
    const teacherScheduleSummary =
      buildTeacherScheduleSummary();

    const deterministicRules =
      buildDeterministicRuleCheckResults();

    const userMessage = {
      id: `user-${Date.now()}`,
      role: "user",
      type: "message",
      text,
      createdAt: new Date().toISOString(),
      actions: [],
    };

    onMessagesChange((prev) => [
      ...prev,
      userMessage,
    ]);

    setInput("");
    setIsAgentThinking(true);

    try {
      const response = await fetch(
        "/.netlify/functions/scheduling-agent",
        {
          method: "POST",

          headers: {
            "Content-Type": "application/json",
          },

          body: JSON.stringify({
            message: text,

            conversationHistory: [
              ...(messages || []),
              userMessage,
            ],

            validationSummary: {
              statistics:
                validationReport?.statistics || {},

              errors:
                validationReport?.errors || [],

              warnings:
                validationReport?.warnings || [],
            },

            entitySummary: {
              teachers:
                agentContext?.schoolData?.teachers?.map(
                  (teacher) => ({
                    id: teacher.id,
                    name: teacher.name,
                  })
                ) || [],

              classes:
                agentContext?.schoolData?.classes || [],

              meetings:
                agentContext?.schoolData?.meetings?.map(
                  (meeting) => ({
                    id: meeting.id,
                    name: meeting.name,
                  })
                ) || [],
            },

            teacherScheduleSummary,

            rules: rules || [],

            approvedExceptions:
              approvedExceptions || [],

            formalRuleEvaluations:
              deterministicRules.evaluations,
          }),
        }
      );

      const data = await response.json();

      console.log(
        "Scheduling agent proposed action:",
        data.proposedAction
      );

      if (!response.ok) {
        throw new Error(
          data?.error ||
          "שגיאה בתקשורת עם סוכן השיבוץ"
        );
      }

      recordTelemetry(data.telemetry);

      let proposedAction =
        data.proposedAction;

      const ruleCheckResults =
        mergeRuleCheckResults(
          Array.isArray(data.ruleCheckResults)
            ? data.ruleCheckResults
            : [],
          deterministicRules.ruleCheckResults,
        );

      if (ruleCheckResults.length > 0) {
        onRulesChange((prev) =>
          prev.map((rule) => {
            const result =
              ruleCheckResults.find(
                (item) =>
                  item.ruleId === rule.id
              );

            if (!result) {
              return rule;
            }

            return {
              ...rule,

              checkStatus:
                result.status,

              checkSummary:
                result.summary,

              checkViolations:
                result.violations || [],

              checkedAt:
                new Date().toISOString(),
            };
          })
        );
      }

      if (
        proposedAction?.type ===
        "proposeScheduleMove" &&
        onTryWorkspaceMove
      ) {
        const attemptResult =
          onTryWorkspaceMove(
            proposedAction
          );

        proposedAction = {
          ...proposedAction,

          simulation: {
            success:
              attemptResult.success,

            error:
              attemptResult.error || null,

            validationStatistics:
              attemptResult
                .validationReport
                ?.statistics || null,

            validationErrors:
              attemptResult
                .validationReport
                ?.errors || [],

            validationComparison:
              attemptResult
                .validationComparison ||
              null,

            workspaceAttemptCount:
              attemptResult.workspace
                ?.attempts?.length || 0,
          },
        };
        const evaluationData =
          await askAgentToEvaluateAttempt({
            attemptedAction:
              proposedAction,

            attemptResult,
          });

        console.log(
          "AGENT ATTEMPT EVALUATION:",
          evaluationData
        );
      }

      const agentMessage = {
        id: `agent-${Date.now()}`,
        role: "agent",
        type: "message",
        text:
          data.reply ||
          "הסוכן לא החזיר תשובה.",
        createdAt: new Date().toISOString(),

        actions: proposedAction
          ? [
            {
              ...proposedAction,
              status: "pending",
            },
          ]
          : [],
      };

      onMessagesChange((prev) => [
        ...prev,
        agentMessage,
      ]);
    } catch (error) {
      console.error(
        "Scheduling agent request failed:",
        error
      );

      const errorMessage = {
        id: `agent-error-${Date.now()}`,
        role: "agent",
        type: "error",
        text:
          "לא הצלחתי ליצור קשר עם סוכן השיבוץ. " +
          (error?.message || ""),
        createdAt: new Date().toISOString(),
        actions: [],
      };

      onMessagesChange((prev) => [
        ...prev,
        errorMessage,
      ]);
    } finally {
      setIsAgentThinking(false);
    }
  }

  //const rules = agentContext?.rules || [];

  //const approvedExceptions = agentContext?.approvedExceptions || [];

  const statistics = validationReport?.statistics || {};

  function handleAddRule() {
    const text = newRuleText.trim();

    if (!text) {
      return;
    }

    const newRule = {
      id: `rule-${Date.now()}`,
      originalText: text,
      status: "unparsed",
      createdAt: new Date().toISOString(),
    };

    onRulesChange((prev) => [...prev, newRule]);

    setNewRuleText("");
  }

  function handleApproveAction(messageId, action) {
    if (
      action.type ===
      "approveMeetingParticipantException"
    ) {
      const newException = {
        type: "meetingParticipant",
        meetingId: action.meetingId,
        teacherId: String(action.teacherId),
      };

      onApprovedExceptionsChange((prev) => {
        const alreadyExists = prev.some(
          (exception) =>
            exception.type ===
            newException.type &&
            exception.meetingId ===
            newException.meetingId &&
            String(exception.teacherId) ===
            newException.teacherId
        );

        if (alreadyExists) {
          return prev;
        }

        return [...prev, newException];
      });

      onMessagesChange((prev) =>
        prev.map((message) => {
          if (message.id !== messageId) {
            return message;
          }

          return {
            ...message,

            actions: message.actions.map(
              (existingAction) =>
                existingAction === action
                  ? {
                    ...existingAction,
                    status: "approved",
                  }
                  : existingAction
            ),
          };
        })
      );
    }

    if (
      action.type === "updateRuleInterpretation"
    ) {
      onRulesChange((prev) =>
        prev.map((rule) => {
          if (rule.id !== action.ruleId) {
            return rule;
          }

          return {
            ...rule,

            status:
              action.formalizationStatus,

            interpretation:
              action.interpretation,

            formalRule: (() => {
              if (!action.formalRuleJson) {
                return null;
              }

              try {
                return JSON.parse(
                  action.formalRuleJson
                );
              } catch (error) {
                console.error(
                  "Failed to parse formal rule JSON:",
                  error
                );

                return null;
              }
            })(),

            clarificationQuestion:
              action.clarificationQuestion,

            parsedAt:
              new Date().toISOString(),
          };
        })
      );

      onMessagesChange((prev) =>
        prev.map((message) => {
          if (message.id !== messageId) {
            return message;
          }

          return {
            ...message,

            actions: message.actions.map(
              (existingAction) =>
                existingAction === action
                  ? {
                    ...existingAction,
                    status: "approved",
                  }
                  : existingAction
            ),
          };
        })
      );

      return;
    }
  }

  function handleDeleteRule(ruleId) {
    onRulesChange((prev) =>
      prev.filter((rule) => rule.id !== ruleId)
    );
  }

  function handleDeleteException(exceptionToDelete) {
    onApprovedExceptionsChange((prev) =>
      prev.filter(
        (exception) =>
          !(
            exception.type === exceptionToDelete.type &&
            exception.meetingId ===
            exceptionToDelete.meetingId &&
            String(exception.teacherId) ===
            String(exceptionToDelete.teacherId)
          )
      )
    );
  }

  return (
    <div className="scheduling-agent-view">
      <h2>סוכן שיבוץ AI</h2>

      <div className="scheduling-agent-telemetry">
        <strong>שימוש API בסשן:</strong>{" "}
        {agentTelemetry.calls} קריאות · {" "}
        {agentTelemetry.inputTokens.toLocaleString()} קלט · {" "}
        {agentTelemetry.outputTokens.toLocaleString()} פלט · {" "}
        {agentTelemetry.totalTokens.toLocaleString()} סה״כ tokens
        {agentTelemetry.lastModel
          ? ` · ${agentTelemetry.lastModel}`
          : ""}
        {agentTelemetry.lastContextChars
          ? ` · context ${agentTelemetry.lastContextChars.toLocaleString()} chars`
          : ""}
      </div>

      <div className="scheduling-agent-panel scheduling-agent-sandbox-panel">
        <div className="scheduling-agent-sandbox-header">
          <div>
            <strong>Python Sandbox v1</strong>
            <div className="scheduling-agent-sandbox-subtitle">
              בדיקת תשתית: ה-Agent קורא metadata כקובץ ומריץ Python מבודד.
            </div>
          </div>

          <button
            type="button"
            onClick={runPythonSandboxTest}
            disabled={isSandboxTesting || !agentContext?.schoolData}
          >
            {isSandboxTesting ? "מריץ Python..." : "בדוק Python Sandbox"}
          </button>
        </div>

        {sandboxTestResult && (
          <div
            className={
              sandboxTestResult.success
                ? "scheduling-agent-sandbox-result success"
                : "scheduling-agent-sandbox-result error"
            }
          >
            {sandboxTestResult.success ? (
              <>
                <div>✓ ה-Sandbox הריץ Python וקרא את metadata.json.</div>
                <div>
                  מורים: {sandboxTestResult.result?.teacherCount ?? "?"} · כיתות: {sandboxTestResult.result?.classCount ?? "?"} · יחידות הוראה: {sandboxTestResult.result?.teachingUnitCount ?? "?"}
                </div>
                <div>
                  Python runs: {sandboxTestResult.telemetry?.codeInterpreterCalls ?? 0} · קובץ קלט: {(sandboxTestResult.inputFile?.bytes ?? 0).toLocaleString()} bytes
                </div>
                {Array.isArray(sandboxTestResult.codeRuns) &&
                  sandboxTestResult.codeRuns.length > 0 && (
                    <details>
                      <summary>הצג את קוד ה-Python וה-logs</summary>
                      {sandboxTestResult.codeRuns.map((run, index) => (
                        <div key={run.id || index} className="scheduling-agent-sandbox-code-run">
                          <strong>הרצה {index + 1}</strong>
                          <pre>{run.code || "(לא הוחזר קוד)"}</pre>
                          {run.logs && (
                            <>
                              <strong>logs</strong>
                              <pre>{run.logs}</pre>
                            </>
                          )}
                        </div>
                      ))}
                    </details>
                  )}
              </>
            ) : (
              <>
                <div>✕ {sandboxTestResult.error || sandboxTestResult.diagnostic?.message || "ה-Sandbox לא עבר את בדיקת התשתית."}</div>
                {sandboxTestResult.checks && (
                  <pre style={{ whiteSpace: "pre-wrap", direction: "ltr", textAlign: "left" }}>
                    {JSON.stringify(sandboxTestResult.checks, null, 2)}
                  </pre>
                )}
                {sandboxTestResult.diagnostic && (
                  <pre style={{ whiteSpace: "pre-wrap", direction: "ltr", textAlign: "left" }}>
                    {JSON.stringify(sandboxTestResult.diagnostic, null, 2)}
                  </pre>
                )}
              </>
            )}
          </div>
        )}
      </div>

      <div className="scheduling-agent-workspace-controls">
        {!workspace ? (
          <button
            type="button"
            onClick={onStartWorkspace}
          >
            התחל סביבת עבודה
          </button>
        ) : (
          <>
            <div>
              סביבת עבודה פעילה
            </div>

            <div>
              ניסיונות:{" "}
              {workspace.attempts?.length || 0}
            </div>

            <button
              type="button"
              onClick={onClearWorkspace}
            >
              סגור סביבת עבודה
            </button>
          </>
        )}
      </div>
      <div className="scheduling-agent-layout">
        <section className="scheduling-agent-chat">
          <h3>שיחה עם הסוכן</h3>

          <div className="scheduling-agent-messages">
            {messages.map((message, index) => (
              <div
                key={message.id}
                className={
                  message.role === "user"
                    ? "scheduling-agent-message user"
                    : "scheduling-agent-message agent"
                }
              >
                <strong>{message.role === "user" ? "אתה" : "הסוכן"}</strong>

                <div>{message.text}</div>
                {Array.isArray(message.actions) &&
                  message.actions.map(
                    (action, actionIndex) => (
                      <div
                        key={actionIndex}
                        className="scheduling-agent-action"
                      >
                        <div>
                          {action.explanation}
                        </div>

                        {action.status === "pending" &&
                          action.type !== "proposeScheduleMove" && (
                            <button
                              type="button"
                              onClick={() =>
                                handleApproveAction(
                                  message.id,
                                  action
                                )
                              }
                            >
                              {action.type ===
                                "approveMeetingParticipantException"
                                ? "אשר חריג"
                                : action.type ===
                                  "updateRuleInterpretation"
                                  ? "אשר פרשנות"
                                  : "אשר פעולה"}
                            </button>
                          )}

                        {action.status === "pending" &&
                          action.type === "proposeScheduleMove" && (
                            <div className="scheduling-agent-action-pending-validation">
                              הצעת שינוי — טרם נבדקה מול כלל אילוצי המערכת
                            </div>
                          )}

                        {action.status === "pending" &&
                          action.type === "proposeScheduleMove" && (
                            <div className="scheduling-agent-action-pending-validation">

                              {action.simulation?.success ? (
                                <>
                                  <div>
                                    ✓ השינוי עבר סימולציה
                                    ראשונית מול ה־validator.
                                  </div>

                                  <div>
                                    שגיאות Core Validator לאחר
                                    השינוי:{" "}
                                    {action.simulation
                                      ?.validationStatistics
                                      ?.errorCount ?? 0}
                                  </div>

                                  <div>
                                    עדיין נדרשת בדיקת חוקי־העל
                                    מול המערכת המדומה.
                                  </div>
                                </>
                              ) : (
                                <div>
                                  ✕ לא ניתן לבצע אפילו סימולציה
                                  של ההצעה:{" "}
                                  {action.simulation?.error ||
                                    "שגיאה לא ידועה"}
                                </div>
                              )}

                            </div>
                          )}

                        {action.simulation
                          ?.workspaceAttemptCount > 0 && (
                            <div>
                              ניסיון בסביבת העבודה:{" "}
                              {
                                action.simulation
                                  .workspaceAttemptCount
                              }
                            </div>
                          )}

                        {action.status === "approved" && (
                          <div className="scheduling-agent-action-approved">
                            ✓ החריג אושר
                          </div>
                        )}
                      </div>
                    )
                  )}
              </div>
            ))}
          </div>

          {isAgentThinking && (
            <div className="scheduling-agent-thinking">
              הסוכן בודק את הנתונים...
            </div>
          )}

          <div className="scheduling-agent-input-row">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="כתוב לסוכן..."
              rows={3}
            />

            <button
              type="button"
              onClick={handleSend}
              disabled={!input.trim() || isAgentThinking}
            >
              {isAgentThinking ? "חושב..." : "שלח"}
            </button>
          </div>
        </section>

        <aside className="scheduling-agent-sidebar">
          <div className="scheduling-agent-panel">
            <h3>חוקי־על</h3>

            <textarea
              value={newRuleText}
              onChange={(e) => setNewRuleText(e.target.value)}
              placeholder="לדוגמה: כל כיתות ד' חייבות לסיים בכל יום באותה שעה"
              rows={3}
              style={{ width: "100%" }}
            />

            <button
              type="button"
              onClick={handleAddRule}
              disabled={!newRuleText.trim()}
            >
              הוסף חוק
            </button>

            {rules.length === 0 ? (
              <p>עדיין לא הוגדרו חוקי־על.</p>
            ) : (
              <ul className="scheduling-agent-list">
                {rules.map((rule) => (
                  <li
                    key={rule.id}
                    className="scheduling-agent-list-item"
                  >
                    <div className="scheduling-agent-list-content">
                      <div>
                        {rule.originalText}
                      </div>

                      <small>
                        סטטוס: {rule.status}
                      </small>

                      {rule.checkStatus && (
                        <div className="scheduling-agent-rule-check">
                          <div>
                            מצב במערכת:{" "}
                            <strong>
                              {rule.checkStatus === "satisfied"
                                ? "✓ מתקיים"
                                : rule.checkStatus === "violated"
                                  ? "✕ מופר"
                                  : rule.checkStatus === "stale"
                                    ? "נדרשת בדיקה מחדש"
                                    : "לא ניתן לקבוע"}
                            </strong>
                          </div>

                          {rule.checkStatus === "stale" ? (
                            <div>
                              מערכת השעות השתנתה מאז הבדיקה האחרונה.
                            </div>
                          ) : (
                            <>
                              {rule.checkSummary && (
                                <div>
                                  {rule.checkSummary}
                                </div>
                              )}

                              {Array.isArray(rule.checkViolations) &&
                                rule.checkViolations.length > 0 && (
                                  <ul>
                                    {rule.checkViolations.map(
                                      (violation, index) => (
                                        <li key={index}>
                                          {violation.day &&
                                            `יום ${violation.day}: `}

                                          {violation.explanation}
                                        </li>
                                      )
                                    )}
                                  </ul>
                                )}
                            </>
                          )}
                        </div>
                      )}

                    </div>

                    <button
                      type="button"
                      className="scheduling-agent-delete-button"
                      onClick={() =>
                        handleDeleteRule(rule.id)
                      }
                    >
                      מחק
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="scheduling-agent-panel">
            <h3>חריגים מאושרים</h3>

            {approvedExceptions.length === 0 ? (
              <p>אין חריגים מאושרים.</p>
            ) : (
              <ul className="scheduling-agent-list">
                {approvedExceptions.map(
                  (exception, index) => (
                    <li
                      key={`${exception.type}-${exception.meetingId}-${exception.teacherId}-${index}`}
                      className="scheduling-agent-list-item"
                    >
                      <div className="scheduling-agent-list-content">
                        <div>
                          {exception.type}
                          {" — "}
                          {exception.teacherId || ""}
                        </div>

                        {exception.meetingId && (
                          <small>
                            {exception.meetingId}
                          </small>
                        )}
                      </div>

                      <button
                        type="button"
                        className="scheduling-agent-delete-button"
                        onClick={() =>
                          handleDeleteException(exception)
                        }
                      >
                        מחק
                      </button>
                    </li>
                  )
                )}
              </ul>
            )}
          </div>
        </aside>
      </div>
    </div>
  );
}
