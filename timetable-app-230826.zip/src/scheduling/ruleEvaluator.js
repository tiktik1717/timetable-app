export function evaluateFormalRule({
  rule,
  schedule,
  schoolData,
}) {
  if (!rule?.formalRule) {
    return {
      supported: false,
      valid: null,
      violations: [],
    };
  }

  const formalRule = rule.formalRule;

  if (
    formalRule.scope === "teacher_day" &&
    formalRule.constraint === "no_internal_gaps"
  ) {
    return evaluateTeacherNoInternalGaps({
      rule,
      formalRule,
      schedule,
      schoolData,
    });
  }

  return {
    supported: false,
    valid: null,
    violations: [],
  };
}
function evaluateTeacherNoInternalGaps({
  rule,
  formalRule,
  schedule,
  schoolData,
}) {
  const teacherId = String(
    formalRule.teacherId
  );

  const teachingUnits =
    schoolData?.teachingUnits || [];

  const violations = [];

  for (const [day, daySchedule] of Object.entries(
    schedule || {}
  )) {
    const teachingHours = [];

    for (const [
      className,
      classSchedule,
    ] of Object.entries(daySchedule || {})) {
      for (const [
        hourKey,
        cellValue,
      ] of Object.entries(classSchedule || {})) {
        const hour = Number(hourKey);

        const unitIds = Array.isArray(cellValue)
          ? cellValue
          : cellValue
            ? [cellValue]
            : [];

        const teacherIsHere = unitIds.some(
          (unitId) => {
            const unit = teachingUnits.find(
              (item) => item.id === unitId
            );

            if (!unit) {
              return false;
            }

            // ישיבות צוות אינן נחשבות כרגע
            // כשעת הוראה לצורך חוק החלונות.
            if (unit.type === "teamMeeting") {
              return false;
            }

            return (
              String(unit.teacherId) ===
              teacherId
            );
          }
        );

        if (teacherIsHere) {
          teachingHours.push(hour);
        }
      }
    }

    const uniqueHours = [
      ...new Set(teachingHours),
    ].sort((a, b) => a - b);

    if (uniqueHours.length <= 1) {
      continue;
    }

    const firstHour = uniqueHours[0];
    const lastHour =
      uniqueHours[uniqueHours.length - 1];

    const missingHours = [];

    for (
      let hour = firstHour;
      hour <= lastHour;
      hour += 1
    ) {
      if (!uniqueHours.includes(hour)) {
        missingHours.push(hour);
      }
    }

    if (missingHours.length > 0) {
      violations.push({
        day,
        teacherId,
        firstHour,
        lastHour,
        gapHours: missingHours,
      });
    }
  }

  return {
    supported: true,
    valid: violations.length === 0,
    violations,
    ruleId: rule.id,
  };
}

/**
 * Evaluate every currently formalized rule against a schedule.
 * Unsupported formal rules are returned explicitly rather than silently ignored.
 * This gives the Agent/Validator pipeline one deterministic entry point for
 * formal super-rules while the rule language is still evolving.
 */
export function evaluateFormalRules({
  rules = [],
  schedule,
  schoolData,
}) {
  return (rules || [])
    .filter((rule) => rule?.formalRule)
    .map((rule) => {
      const result = evaluateFormalRule({
        rule,
        schedule,
        schoolData,
      });

      return {
        ruleId: rule.id,
        originalText: rule.originalText || "",
        interpretation: rule.interpretation || "",
        ...result,
      };
    });
}

/**
 * Convert deterministic evaluator results to the same shape used by the
 * Scheduling Agent ruleCheckResults contract.
 */
export function formalRuleEvaluationsToRuleCheckResults(
  evaluations = [],
) {
  return evaluations.map((result) => {
    if (!result.supported) {
      return {
        ruleId: result.ruleId,
        status: "unknown",
        summary: "החוק פורמלי אך עדיין אין evaluator דטרמיניסטי שתומך בו.",
        violations: [],
        source: "formal-rule-evaluator",
      };
    }

    return {
      ruleId: result.ruleId,
      status: result.valid ? "satisfied" : "violated",
      summary: result.valid
        ? "החוק מתקיים לפי הבדיקה הדטרמיניסטית."
        : `נמצאו ${result.violations?.length || 0} הפרות בבדיקה הדטרמיניסטית.`,
      violations: (result.violations || []).map((violation) => ({
        day: violation.day ?? null,
        hours: violation.gapHours || violation.hours || [],
        entityId:
          violation.teacherId ||
          violation.className ||
          violation.entityId ||
          null,
        explanation: JSON.stringify(violation),
        detailsJson: JSON.stringify(violation),
      })),
      source: "formal-rule-evaluator",
    };
  });
}
